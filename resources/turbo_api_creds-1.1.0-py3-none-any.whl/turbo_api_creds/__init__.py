import secrets
import cryptography
from cryptography.fernet import Fernet
from pathlib import Path
import os.path
import os
import base64

class TurboCredStoreException(Exception):
    pass

class InvalidToken(TurboCredStoreException):
    pass

class TurboCredStore:
    """

    """
    __default_cred_dir = os.path.join(Path.home(), ".turbo_services_api_creds")
    __default_enc_key_file = os.path.join(__default_cred_dir, ".key")
    __default_cred_file = os.path.join(__default_cred_dir, ".turboapicred")

    def __gen_enc_key(self):
        return Fernet.generate_key().decode()

    def __encrypt(self, s, k):
        return Fernet(k).encrypt(s).decode()

    def __decrypt(self, s, k):
        return Fernet(k).decrypt(s.encode())

    def __get_from_file_or_string(self, val):
        if os.path.exists(val):
            with open(val, "r") as c:
                return c.read()
        else:
            return val

    def __init_enc_key(self):
        if not os.path.exists(self.__default_cred_dir):
            os.mkdir(self.__default_cred_dir)

        enc_key_file = self.__default_enc_key_file
        if not os.path.exists(enc_key_file):
            with open(enc_key_file, "w") as f:
                f.write(self.__gen_enc_key())

        return self.__get_from_file_or_string(enc_key_file).encode()

    def __get_encryption_key(self, k=None):
        if k:
            val = self.__get_from_file_or_string(k)
            if val is None:
                val = self.__gen_enc_key()
                with open(k, "w") as f:
                    f.write(val)
            return val
        else:
            return self.__init_enc_key()

    def __get_auth_string(self, s=None):
        if s:
            return self.__get_from_file_or_string(s)
        else:
            return self.__get_from_file_or_string(self.__default_cred_file)

    @property
    def default_exists(self):
        return os.path.exists(self.__default_enc_key_file)

    def gen_auth_string(self, username, password, file_path=None, key=None, default=False):
        """Generates a new authentication string

        Args:
            username (str): Username
            password (str): Password
            file_path (str, optional): The path to write the auth_string to.
            key (str, optional): The encryption key, or the path to it.
                If None, the TurboCredStore default is used.
            default (bool, optional): If True, the authentication string will be
                set as the new default

        Returns:
            String (Basic Auth Credentials)
        """
        creds = base64.b64encode(":".join([username, password]).encode())
        k = self.__get_encryption_key(key)
        ct = self.__encrypt(creds, k)
        if default:
            file_path = self.__default_cred_file
        if file_path:
            with open(file_path, "w") as f:
                f.write(ct)
        return ct

    def gen_encryption_key(self, file_path=None):
        """Generates a new encryption key

        Args:
            file_path (str, optional): The path to write the key to.

        Returns:
            String
        """
        key = self.__gen_enc_key()
        if file_path:
            with open(file_path, "w") as f:
                f.write(key)
        return key

    def decrypt(self, auth=None, key=None):
        """Decrypts an authentication string

        Args:
            auth (str, optional): The authentication string, or the path to it.
                If None, the TurboCredStore default is used.
            key (str, optional): The encryption key, or the path to it.
                If None, the TurboCredStore default is used.

        Returns:
            String (Basic Auth Credentials)
        """
        try:
            return self.__decrypt(self.__get_auth_string(auth),
                                  self.__get_encryption_key(key))
        except:
            raise InvalidToken()
