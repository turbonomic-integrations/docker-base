# AutoPlanner
__title__ = "turbo_api_creds"
__description__ = "Encrypt and Decrypt Turbonomic User Credentials For API Access"
__version__ = "1.1.0"
__author__ = "Austin Portal, R.A. Stern"
__author_email__ = "support@turbonomic.com"
