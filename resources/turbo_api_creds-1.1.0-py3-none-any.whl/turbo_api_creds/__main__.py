from getpass import getpass
from turbo_api_creds import TurboCredStore
import argparse
import sys
from getpass import getpass
import cmd
import re
import traceback

class TurboAuthShell(cmd.Cmd):
    """Creates and decrypts authentication strings for use in Pro-Services
    integrations
    """

    def _get_auth(self):
        user = input("Username: ")
        passw = getpass(f"{user} Password: ")
        return user, passw

    def _option_prompt(self, msg, options):
        resp = input(f"{msg} {options}: ")
        if resp not in options:
            return self._option_prompt(msg, options)
        return resp

    def _parse_args(self, args):
        a = []
        for match in re.findall(r'\'([^\']+)\'|"([^"]+)"|(--[^"\s]+)|([^"\s]+)', args):
            for m in match:
                if m:
                    a.append(m)
        return a

    def do_decrypt(self, arg):
        """Decrypts an authentication string

        Args:
            auth_string: The auth string or the path to it
            key (optional): The encryption key. If none is provided, the default
                is used
        """
        arg_parser = argparse.ArgumentParser(description="Decrypt Auth String")
        arg_parser.add_argument("auth_string", action="store",
                                help="Auth string or a file containing it")
        arg_parser.add_argument("--key", action="store",
                                help="Encryption key or a file containing it")
        args = arg_parser.parse_args(self._parse_args(arg))
        if args.auth_string == "default":
            args.auth_string = None
        return TurboCredStore().decrypt(args.auth_string, args.key)

    def do_create_private_key(self, arg):
        """Creates a new encryption key to use when generating auth strings

        Args:
            file (optional): The path to write the string to.
        """
        arg_parser = argparse.ArgumentParser(description="Create Encryption Key")
        arg_parser.add_argument("--file", action="store",
                                help="File to save key to")
        args = arg_parser.parse_args(self._parse_args(arg))
        return TurboCredStore().gen_encryption_key(args.file)

    def do_create_auth(self, arg):
        """Creates an auth string

        Args:
            file (optional): The path to write the string to.
            key (optional): The path to the encryption key to use. Default is
                used if no key is provided

        """
        arg_parser = argparse.ArgumentParser(description="Create an Auth String")
        arg_parser.add_argument("--file", "-f", action="store",
                                help="File to save credentials to")
        arg_parser.add_argument("--key", action="store",
                                help="Private key to use in encoding")
        args = arg_parser.parse_args(self._parse_args(arg))
        return TurboCredStore().gen_auth_string(*self._get_auth(), args.file, key=args.key)

    def do_add_default(self, arg):
        """Creates default auth string
        """
        auth = TurboCredStore()
        if auth.default_exists:
            if self._option_prompt("Overwrite default credentials?", ["y", "n"]) == "n":
                return
        return auth.gen_auth_string(*self._get_auth(), default=True)

def main():
    try:
        resp = TurboAuthShell().onecmd(" ".join(sys.argv[1:]))
        if resp:
            print(resp)
    except Exception as e:
        print("Error - {}".format(e.__class__.__name__))

if __name__ == "__main__":
    main()
